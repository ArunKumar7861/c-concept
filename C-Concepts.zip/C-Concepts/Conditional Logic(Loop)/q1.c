//q-1. WAP to print 972 to 897 using for loop

#include<stdio.h> 

main() {
    int i; // Variable to control the loop
    
    // For loop to iterate from 972 down to 897
    for(i = 972; i >= 897; i--) {
        printf("%d\n", i); // Print the current value of i followed by a newline
    }
}

