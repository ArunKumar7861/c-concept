//q-1. Display This Information using printf 
//	 a. Your Name 
//	 b. Your Birth date 
//	 c. Your Age 
//	 d. Your Address 

#include <stdio.h> // Include the standard input-output header file

// Main function, the entry point of the program
main() {
    // Print the name "ARUN"
    printf("Arun kumar");
    
    // Print the date of birth
    printf("\n24-08-2004");
    
    // Print the age
    printf("\nAge is 20");
    
    // Print the abbreviation "vastral"
    printf("\n vastral");

}

